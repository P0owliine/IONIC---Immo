<?php


namespace App\Manager;


use App\Entity\Connexion;
use PDO;

class FavorisManager
{
    public function getFavorisByIdCompte($id_compte = null)
    {
        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        $req = $objPdo->prepare("SELECT * FROM favoris, annonce WHERE favoris.id_annonce = annonce.id AND favoris.id_compte = ?");
        $req->execute(array($id_compte));
        $favoris = $req->fetchAll(PDO::FETCH_ASSOC);
        foreach ($favoris as $fav) {
            $reqImages = $objPdo->prepare("SELECT * FROM image WHERE id_annonce = ? LIMIT 1");
            $reqImages->execute(array($fav['id']));
            $image = $reqImages->fetch(PDO::FETCH_ASSOC);

            $favoris[$fav['id']]['images'] = $image;
        }
        return $favoris;
    }

    public function addFavoris($id_annonce, $id_compte){
        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        $req = $objPdo->prepare("INSERT INTO favoris(id_annonce, id_compte) VALUES(?,?);");

        $req->execute(array($id_annonce, $id_compte));
        $count = $req->rowCount();
        return $count;
    }
}

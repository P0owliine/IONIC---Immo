<?php


namespace App\Manager;


use App\Entity\Connexion;
use PDO;

class MessageManager
{
    public function getMessageByIdCompte($id_compte)
    {
        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        $req = $objPdo->prepare("SELECT message.id, annonce.title, message.id_sender, message.message, message.date
                                 FROM annonce, message
                                 WHERE annonce.id = message.id_annonce AND annonce.id_compte = ?");
        $req->execute(array($id_compte));
        $messages = $req->fetchAll(PDO::FETCH_ASSOC);
        foreach($messages as $message){
            $reqUsername = $objPdo->prepare("SELECT username FROM compte WHERE id = ?");
            $reqUsername->execute(array($message['id_sender']));
            $messages[$message['id']]['sender'] = $reqUsername->fetch(PDO::FETCH_ASSOC);
        }

        return $messages;
    }

    public function addMessage($id_annonce, $id_sender, $message, $date){
        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        $req = $objPdo->prepare("INSERT INTO message(id_annonce, id_sender, message, date) VALUES (?,?,?,?);");

        $req->execute(array($id_annonce, $id_sender, $message, $date));
        $count = $req->rowCount();
        return $count;
    }
}

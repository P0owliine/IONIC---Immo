<?php
namespace App\Manager;
use App\Entity\Connexion;
use PDO;

class CompteManager
{

    public function getCompteById($id){

        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        $req = $objPdo->prepare("SELECT id, username FROM compte WHERE id = ?");
        $req->execute(array($id));
        $compte = $req->fetchAll(PDO::FETCH_ASSOC);

        return $compte;
    }

    public function getCompteByUsername($username){

        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        $req = $objPdo->prepare("SELECT id, username FROM compte WHERE username = ?");
        $req->execute(array($username));
        $compte = $req->fetchAll(PDO::FETCH_ASSOC);

        return $compte;
    }

    public function addCompte($username, $password){
        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        $req = $objPdo->prepare("INSERT INTO compte(username, password) VALUES (?,?);");
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $req->execute(array($username, $hash));
        $count = $req->rowCount();
        return $count;
    }

    public function login($username, $password){
        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        $req = $objPdo->prepare("SELECT password FROM compte WHERE username = ?;");
        $req->execute(array($username));
        $hash = $req->fetch()['password'];
        if(!is_null($hash)){
            if(password_verify($password, $hash)){
                return 1;
            }
        }
        return 0;
    }
}

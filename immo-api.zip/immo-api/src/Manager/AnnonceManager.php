<?php


namespace App\Manager;


use App\Entity\Connexion;
use PDO;

class AnnonceManager
{
    public function getAnnonces($id = null)
    {
        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        if(!is_null($id)){
            $req = $objPdo->prepare("SELECT * FROM annonce WHERE id = ?");
            $req->execute(array($id));
            $annonces = $req->fetchAll(PDO::FETCH_ASSOC);
            $reqImages = $objPdo->prepare("SELECT * FROM image WHERE id_annonce = ?");
            $reqImages->execute(array($id));
            $images = $reqImages->fetchAll(PDO::FETCH_ASSOC);

            $annonces['images'] = $images;



        } else {
            $req = $objPdo->prepare("SELECT * FROM annonce");
            $req->execute();
            $annonces = $req->fetchAll(PDO::FETCH_ASSOC);

            foreach ($annonces as $annonce) {
                $reqImages = $objPdo->prepare("SELECT * FROM image WHERE id_annonce = ? LIMIT 1");
                $reqImages->execute(array($annonce['id']));
                $image = $reqImages->fetch(PDO::FETCH_ASSOC);

                $annonces[$annonce['id']]['images'] = $image;
            }
        }


        return $annonces;
    }

    public function getAnnoncesByCompte($id_compte){
        $connexion = new Connexion();
        $objPdo = $connexion->getConnexion();
        $req = $objPdo->prepare("SELECT * FROM annonce WHERE id_compte = ?");
        $req->execute(array($id_compte));
        $annonces = $req->fetchAll(PDO::FETCH_ASSOC);

        foreach ($annonces as $annonce) {
            $reqImages = $objPdo->prepare("SELECT * FROM image WHERE id_annonce = ? LIMIT 1");
            $reqImages->execute(array($annonce['id']));
            $image = $reqImages->fetch(PDO::FETCH_ASSOC);

            $annonces[$annonce['id']]['images'] = $image;
        }
        return $annonces;
    }


}

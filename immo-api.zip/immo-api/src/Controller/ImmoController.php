<?php


namespace App\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;
use App\Entity\Comments;

/**
 * @Route("/comments", name="comments")
 */
class ImmoController extends AbstractController
{




    /**
     * @Route("/getComments", name="_get_comments")
     */
    public function getComments(){
        $comments = new Comments();
        if(!empty($_POST['entityUuid'])) {
            $Uuid = $_POST['entityUuid'];

            return new Response(json_encode($comments->getComments($Uuid)));
        } else {
            return new Response(0);
        }
    }

    /**
     * @Route("/updateComments", name="_update_comments")
     */
    public function updateComments(){
        $comments = new Comments();
        if (!empty($_POST['id']) && !empty($_POST['message'])) {
            $id = $_POST['id'];
            $dateMsg = date("Y-m-d H:i:s");
            $message = $_POST['message'];

            return new Response(json_encode($comments->updateComments($dateMsg, $message, $id)));
        } else {
            return new Response(0);
        }
    }

    /**
     * @Route("/delComments", name="_del_comments")
     */
    public function delComments(){
        $comments = new Comments();
        if(!empty($_POST['id'])) {
            $id = $_POST['id'];

            return new Response(json_encode($comments->delComments($id)));
        } else {
            return new Response(0);
        }
    }

}


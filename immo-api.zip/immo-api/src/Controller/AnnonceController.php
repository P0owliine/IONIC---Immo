<?php


namespace App\Controller;

use App\Entity\Comments;
use App\Manager\AnnonceManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

/**
 * @Route("/annonce", name="annonce")
 */
class AnnonceController
{
    /**
     * @Route("/getAnnonces/{id}", name="_get_annonces")
     */
    public function getAnnonces($id = null){
        $am = new AnnonceManager();
        return new Response(json_encode($am->getAnnonces($id)));

    }
    /**
     * @Route("/getAnnoncesByCompte/{id_compte}", name="_get_annonces_by_compte")
     */
    public function getAnnoncesByCompte($id_compte){
        $am = new AnnonceManager();
        return new Response(json_encode($am->getAnnoncesByCompte($id_compte)));
    }
}

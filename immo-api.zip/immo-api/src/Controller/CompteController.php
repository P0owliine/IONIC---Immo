<?php
namespace App\Controller;
use App\Manager\CompteManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

/**
* @Route("/compte", name="compte")
*/
class CompteController
{
    /**
    * @Route("/getCompte/{id}", name="_get_compte", requirements={"id" = "\d+"})
    */
    public function getCompte($id){
        $cm = new CompteManager();
        return new Response(json_encode($cm->getCompteById($id)));

    }

    /**
     * @Route("/getCompteByUsername/{username}", name="_get_compte_by_username")
     */
    public function getCompteByUsername($username){
        $cm = new CompteManager();
        return new Response(json_encode($cm->getCompteByUsername($username)));

    }


    /**
    * @Route("/addCompte", name="_add_compte")
    */
    public function addCompte(){
        $cm = new CompteManager();
        $data = json_decode(file_get_contents('php://input'), true);

        if(!empty($data['username']) && !empty($data['password'])) {
            $username = $data['username'];
            $password = $data['password'];
            return new Response(json_encode($cm->addCompte($username, $password)));
        } else {
            return new Response(0);
        }
    }

    /**
     * @Route("/login", name="_login")
     */
    public function login(){
        $cm = new CompteManager();
        $data = json_decode(file_get_contents('php://input'), true);

        if(!empty($data['username']) && !empty($data['password'])) {
            $username = $data['username'];
            $password = $data['password'];
            return new Response(json_encode($cm->login($username, $password)));
        } else {
            return new Response(0);
        }
    }

}

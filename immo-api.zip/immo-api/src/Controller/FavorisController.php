<?php

namespace App\Controller;


use App\Manager\FavorisManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

/**
 * @Route("/favoris", name="favoris")
 */
class FavorisController
{
    /**
     * @Route("/getFavoris/{id_compte}", name="_get_favoris", requirements={"id_compte" = "\d+"})
     */
    public function getFavoris($id_compte){
        $fm = new FavorisManager();
        return new Response(json_encode($fm->getFavorisByIdCompte($id_compte)));

    }


    /**
     * @Route("/addFavoris", name="_add_favoris")
     */
    public function addFavoris(){
        $fm = new FavorisManager();
        $data = json_decode(file_get_contents('php://input'), true);

        if(!empty($data['id_compte']) && !empty($data['id_annonce'])) {
            $id_annonce = $data['id_annonce'];
            $id_compte = $data['id_compte'];
            return new Response(json_encode($fm->addFavoris($id_annonce, $id_compte)));
        } else {
            return new Response(0);
        }
    }
}

<?php

namespace App\Controller;


use App\Manager\MessageManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Response;

/**
 * @Route("/message", name="message")
 */
class MessageController {

    /**
     * @Route("/getMessage/{id_compte}", name="_get_message", requirements={"id_compte" = "\d+"})
     */
    public function getMessage($id_compte){
        $am = new MessageManager();
        return new Response(json_encode($am->getMessageByIdCompte($id_compte)));

    }


    /**
     * @Route("/addMessage", name="_add_message")
     */
    public function addMessage(){
        $mm = new MessageManager();
        $data = json_decode(file_get_contents('php://input'), true);
        if(!empty($data['message']) && !empty($data['id_annonce']) && !empty($data['id_sender'])) {
            $message = $data['message'];
            $id_annonce = $data['id_annonce'];
            $id_sender = $data['id_sender'];
            $date = date('Y-m-d H:i:s');

            return new Response(json_encode($mm->addMessage($id_annonce, $id_sender, $message, $date)));
        } else {
            return new Response("erreur");
        }
    }


}

<?php

namespace App\Entity;

use PDO;
use Exception;

class Connexion
{
  protected $connexion = null;

  /**
   * @return mixed
   */
  public function getConnexion()
  {
    return $this->connexion;
  }

  /**
   * @param mixed $connexion
   */
  public function setConnexion($connexion)
  {
    $this->connexion = $connexion;
  }

  public function __construct()
  {
    if (is_null($this->getConnexion())) {
      try {
        $connexion = new PDO('mysql:host=devbdd.iutmetz.univ-lorraine.fr;port=3306;dbname=lagrang12u_immo', 'lagrang12u_appli', '300894');
        $this->setConnexion($connexion);
      } catch (Exception $exception) {
        die($exception->getMessage());
      }
    }
  }


}
